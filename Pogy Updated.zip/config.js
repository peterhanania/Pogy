module.exports = {
 "verification": "",
 "description": "Pogy is a multi-purpose discord bot ready to skill up and boost up your Discord server!",
 "domain": "", // domain
 "google_analitics": "", // google analitics
 "token": process.env.TOKEN,
 "https":"https://", // leave as is
 "port":"5003",

 "client_id":"", // bot client ID
 "secret":"" // bot client secret for auth

}


// for dashboard, read more on https://github.com/IgorKowalczyk/majobot
